package examplemodel.editorcustomizations;

import library.LibraryPackage;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;
import org.unicase.ui.meeditor.mecontrols.METextControl;

public class EMailMEControl extends METextControl {


	public EMailMEControl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int canRender(IItemPropertyDescriptor arg0, EObject arg1) {
//		Object feature = arg0.getFeature(arg1);
//		if (feature.equals(LibraryPackage.eINSTANCE.getWriter_EMail())) {
//			return 2;
//		}
		return 0;
	}

	@Override
	public Control createControl(Composite parent, int style) {

		Composite composite = getToolkit().createComposite(parent, style);
		GridLayout gridLayout = new GridLayout(2, false);
		composite.setLayout(gridLayout);
		GridDataFactory.fillDefaults().align(SWT.FILL, SWT.CENTER).grab(true,
				true).applyTo(composite);
		final Text txtEmail = (Text) super.createControl(composite, style);

		GridDataFactory.fillDefaults().align(SWT.FILL, SWT.CENTER).grab(true,
				true).applyTo(txtEmail);
		final Action mail = new Action("Send email", SWT.PUSH) {

			@Override
			public void run() {
				String email = txtEmail.getText();
				Program.launch("mailto:" + email);
			}

		};
		Button button = new Button(composite, SWT.PUSH);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				mail.run();
			}

		});
		button.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false));
		button.setText("send Mail");

		return composite;
	}

}
