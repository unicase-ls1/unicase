package examplemodel.navigatorcustomizations;

import library.Library;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.unicase.ui.common.ModelElementOpener;
import org.unicase.ui.common.util.DefaultLabelProvider;

public class LibraryOpener implements ModelElementOpener {

	public LibraryOpener() {
		// TODO Auto-generated constructor stub
	}

	public int canOpen(EObject eObject) {
//		if (eObject instanceof Library) {
//			return 2;
//		}
		return DONOTOPEN;
	}

	public void openModelElement(final EObject library) {
		Dialog messageBox = new Dialog(Display.getDefault().getActiveShell()) {

			@Override
			protected Control createDialogArea(Composite parent) {
				GridData data = new GridData(SWT.CENTER, SWT.CENTER, true, true);
				Composite area = new Composite(parent, SWT.NONE);
				area.setLayout(new GridLayout());
				area.setLayoutData(data);

				TableViewer viewer = new TableViewer(parent);
				viewer.setLabelProvider(new DefaultLabelProvider());
				viewer.add(((Library) library).getBooks().toArray());
				return area;
			}

		};
		messageBox.open();

	}

}
