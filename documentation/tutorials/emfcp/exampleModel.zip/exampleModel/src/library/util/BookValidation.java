package library.util;

import java.util.Set;

import library.Book;
import library.LibraryPackage;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public class BookValidation extends AbstractLibaryConstraint {


	 

	

	@Override
	public Set<EStructuralFeature> validate(EObject eObj,Set<EStructuralFeature> errorFeatures) {
		
		
			   if (eObj instanceof Book) {
			    	 Book book = (Book) eObj;
			       if(book.getTitle()==null||book.getTitle().equals("")){
			    	   errorFeatures.add(LibraryPackage.eINSTANCE.getBook_Title());
			       }

		   }
		   return errorFeatures;


	}

	
}
