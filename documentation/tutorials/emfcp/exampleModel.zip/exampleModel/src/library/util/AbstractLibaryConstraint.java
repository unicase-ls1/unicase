package library.util;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.validation.AbstractModelConstraint;
import org.eclipse.emf.validation.EMFEventType;
import org.eclipse.emf.validation.IValidationContext;

public abstract class AbstractLibaryConstraint extends AbstractModelConstraint {

	@Override
	public IStatus validate(IValidationContext ctx) {
		EObject eObj = ctx.getTarget();

		   EMFEventType eType = ctx.getEventType();

		 

		   if (eType == EMFEventType.NULL) {
			   Set<EStructuralFeature> errorFeatures = new HashSet<EStructuralFeature>();
			   validate(eObj,errorFeatures);
			   if (errorFeatures.isEmpty()){
				   return ctx.createSuccessStatus();
			   }
			   else {
				   for(EStructuralFeature feature: errorFeatures){  
				   ctx.addResult(feature);
				   }
		           return ctx.createFailureStatus(new Object[] { eObj.eClass().getName() });
			   }
		   }
		   return ctx.createSuccessStatus();
		   
	}

	abstract protected Set<EStructuralFeature> validate(EObject eObj, Set<EStructuralFeature> errorFeatures) ;
	

}
