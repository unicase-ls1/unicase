/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package library;

import org.unicase.metamodel.ModelElement;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Base</b></em>'. <!-- end-user-doc -->
 *
 *
 * @see library.LibraryPackage#getLibraryBase()
 * @model abstract="true"
 * @extends ModelElement
 * @generated
 */
public interface LibraryBase extends ModelElement {
} // LibraryBase
