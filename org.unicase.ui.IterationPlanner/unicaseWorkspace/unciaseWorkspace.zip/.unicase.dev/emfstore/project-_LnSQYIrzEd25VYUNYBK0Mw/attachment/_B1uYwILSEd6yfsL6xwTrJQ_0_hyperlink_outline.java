import org.eclipse.jface.action.IContributionManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.text.DocumentEvent;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.hyperlink.AbstractHyperlinkDetector;
import org.eclipse.jface.text.hyperlink.DefaultHyperlinkPresenter;
import org.eclipse.jface.text.hyperlink.IHyperlink;
import org.eclipse.jface.text.hyperlink.IHyperlinkDetector;
import org.eclipse.jface.text.hyperlink.IHyperlinkPresenter;
import org.eclipse.jface.text.source.SourceViewerConfiguration;
import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

//import org.eclipse.ui

import com.onpositive.richtexteditor.viewer.IRichDocumentListener;
import com.onpositive.richtexteditor.viewer.RichTextViewer;
import com.onpositive.richtexteditor.viewer.RichTextViewerControlConfiguration;
import com.onpositive.richtexteditor.viewer.undo.RichDocumentChange;

public class HTMLToBrowser{     

        public static void main(String[] args) {
                Shell shell = new Shell(SWT.SHELL_TRIM);
                shell.setLayout(new GridLayout(2, true));
                final RichTextViewer richTextViewer = new RichTextViewer(shell, SWT.BORDER);
               
                GridData gridData = new GridData(GridData.FILL_BOTH);
                gridData.horizontalSpan = 1;
                gridData.minimumWidth = 200;
                gridData.minimumHeight = 400;
                richTextViewer.getControl().setLayoutData(gridData);            
                final Browser browser = new Browser(shell, SWT.BORDER );
                GridData gridData1 = new GridData(GridData.FILL_BOTH);
                gridData1.horizontalSpan = 1;
                gridData1.minimumWidth = 200;
                gridData1.minimumHeight = 400;
                browser.setLayoutData(gridData1);                               
                richTextViewer.addRichDocumentListener(new IRichDocumentListener(){

                        public void documentAboutToBeChanged(DocumentEvent event) {                             
                        }

                        public void documentChanged(DocumentEvent event,
                                        RichDocumentChange change) {
                                String s = richTextViewer.getLayerManager().getSerializedString();
                                browser.setText(s);             
                        }
                        
                });          
                
                richTextViewer.activatePlugins();
                richTextViewer.showAnnotations(true);
                richTextViewer.showAnnotationsOverview(true);
                
                
//                ===================================================================
                IHyperlinkDetector[] hyperlinkDetectors = {new MyHyperlinkDetector()};
				int eventStateMask = 0;
				richTextViewer.setHyperlinkDetectors(hyperlinkDetectors, eventStateMask);
				IHyperlinkPresenter hyperlinkPresenter = new DefaultHyperlinkPresenter(new RGB(0, 0, 255));
				richTextViewer.setHyperlinkPresenter(hyperlinkPresenter);
//				===================================================================
				
//                IContributionManager toolbarManager = richTextViewer.getToolbarManager();
//                MenuManager menuManager = richTextViewer.getMenuManager();
//                RichTextViewerControlConfiguration configuration = richTextViewer.getConfiguration();
                
                
                Display display = shell.getDisplay();
                shell.pack();
                shell.open();
                while (!shell.isDisposed())
                        if (!display.readAndDispatch())
                        	display.sleep();                


        }

        
        
}



class MyHyperlinkDetector extends  AbstractHyperlinkDetector
{

	public IHyperlink[] detectHyperlinks(ITextViewer textViewer,
			IRegion region, boolean canShowMultipleHyperlinks) {
		
		
		
		IHyperlink[] hyperlinks = {new MyHyperlink()};
		
		return hyperlinks;
	}


	
}

class MyHyperlink implements IHyperlink
{

	public IRegion getHyperlinkRegion() {
		IRegion result = new Region(10, 20);
		// TODO Auto-generated method stub
		return result;
	}

	public String getHyperlinkText() {
		// TODO Auto-generated method stub
		return "foo";
	}

	public String getTypeLabel() {
		// TODO Auto-generated method stub
		return "bar";
	}

	public void open() {
		System.out.println("clicked");
		
	}
	
}
