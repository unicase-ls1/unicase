package examplemodel.navigatorcustomizations;

import java.util.List;

import library.Book;
import library.LibraryPackage;
import library.Writer;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.unicase.metamodel.ModelElement;

public class MEDropAdapter extends org.unicase.ui.common.dnd.MEDropAdapter {

	public MEDropAdapter() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public EClass isDropAdapterfor() {
		return LibraryPackage.eINSTANCE.getBook();
	}

	@Override
	public void drop(DropTargetEvent event, ModelElement target,
			List<ModelElement> source) {
		if (source.get(0) instanceof Writer | target instanceof Book) {
			Writer writer = (Writer) source.get(0);
			((Book) target).setAuthor(writer);
		}
		super.drop(event, target, source);
	}

}
