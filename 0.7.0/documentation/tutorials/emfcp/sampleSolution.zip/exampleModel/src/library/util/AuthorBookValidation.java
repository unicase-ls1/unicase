package library.util;

import java.util.Set;

import library.Book;
import library.LibraryPackage;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public class AuthorBookValidation extends AbstractLibaryConstraint {

	public AuthorBookValidation() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Set<EStructuralFeature> validate(EObject eObj,
			Set<EStructuralFeature> errorFeatures) {
		if(eObj instanceof Book){
			Book book = (Book) eObj;
			if(book.getAuthor()== null){
				errorFeatures.add(LibraryPackage.eINSTANCE.getBook_Author());
			}
		}
		return errorFeatures;
	}

}
